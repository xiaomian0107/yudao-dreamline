document.addEventListener("DOMContentLoaded", function() {
    console.log("屿岛的梦境航线 - 启航！");
});
